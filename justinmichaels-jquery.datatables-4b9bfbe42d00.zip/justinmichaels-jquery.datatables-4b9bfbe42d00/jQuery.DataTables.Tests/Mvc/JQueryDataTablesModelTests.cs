﻿using System;
using System.Collections.ObjectModel;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using jQuery.DataTables.Mvc;

namespace jQuery.DataTables.Tests.Mvc
{
    [TestClass]
    public class JQueryDataTablesModelTests
    {
        [TestMethod]
        public void GetSortedColumns_NoSorting_ReturnsEmptyCollection()
        {
            // arrange
            var model = new JQueryDataTablesModel();

            // act
            var result = model.GetSortedColumns();

            // assert
            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public void GetSortedColumns_Has1Item_ReturnsCollectionWith1Item()
        {
            // arrange
            var expectedSortedColumns = new List<SortedColumn>();
            expectedSortedColumns.Add(new SortedColumn("Source", "desc"));
            var model = new JQueryDataTablesModel()
                            {
                                iSortingCols = 1,
                                iSortCol_ = new ReadOnlyCollection<int>(new int[]{2}),
                                sSortDir_ = new ReadOnlyCollection<string>(new string[] { "desc" }),
                                mDataProp_ = new ReadOnlyCollection<string>(new string[]{"Id", "Name", "Source"})
                            };

            // act
            var result = model.GetSortedColumns();

            // assert
            CollectionAssert.AreEqual(expectedSortedColumns, result);
        }
    }
}
