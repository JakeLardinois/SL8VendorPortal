﻿using jQuery.DataTables.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace jQuery.DataTables.Tests.Mvc
{
    [TestClass]
    public class SortedColumnTests
    {
        [TestMethod]
        public void SortedColumn_SortingDirectionPamaterIsAsc_ReturnsSortingDirectionAscending()
        {
            // arrange
            const string expectedPropertyName = "PropertyName";
            
            // act
            var result = new SortedColumn(expectedPropertyName, "asc");

            // assert
            Assert.AreEqual(expectedPropertyName, result.PropertyName);
            Assert.AreEqual(SortingDirection.Ascending, result.Direction);
        }

        [TestMethod]
        public void SortedColumn_SortingDirectionPamaterIsDesc_ReturnsSortingDirectionAscending()
        {
            // arrange
            const string expectedPropertyName = "PropertyName";

            // act
            var result = new SortedColumn(expectedPropertyName, "desc");

            // assert
            Assert.AreEqual(expectedPropertyName, result.PropertyName);
            Assert.AreEqual(SortingDirection.Descending, result.Direction);
        }

        [TestMethod]
        public void Equals_NullObjectParameter_ReturnsFalse()
        {
            // arrange
            var sortedColumn = new SortedColumn("Prop", "asc");

            // act
            var result = sortedColumn.Equals(null);

            // assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Equals_UnequalTypeObjectParameter_ReturnsFalse()
        {
            // arrange
            var sortedColumn = new SortedColumn("Prop", "asc");
            var comparison = new int();

            // act
            var result = sortedColumn.Equals(comparison);

            // assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Equals_SortingDirectionsNotEqual_ReturnsFalse()
        {
            // arrange
            const string propertyName = "Name";
            var sortedColumn1 = new SortedColumn(propertyName, "asc");
            var sortedColumn2 = new SortedColumn(propertyName, "desc");

            // act
            var result = sortedColumn1.Equals(sortedColumn2);

            // assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Equals_PropertyNameNotEqual_ReturnsFalse()
        {
            // arrange
            const string sortingDirection = "asc";
            var sortedColumn1 = new SortedColumn("Sort1", sortingDirection);
            var sortedColumn2 = new SortedColumn("Sort2", sortingDirection);

            // act
            var result = sortedColumn1.Equals(sortedColumn2);

            // assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Equals_PropertyNameAndSortingDirectionAreEqual_ReturnsTrue()
        {
            // arrange
            const string sortingDirection = "asc";
            const string propertyName = "Prop";
            var sortedColumn1 = new SortedColumn(propertyName, sortingDirection);
            var sortedColumn2 = new SortedColumn(propertyName, sortingDirection);

            // act
            var result = sortedColumn1.Equals(sortedColumn2);

            // assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void GetHashCode_SameObjects_ReturnsSameHashCode()
        {
            // arrange
            const string sortingDirection = "asc";
            const string propertyName = "Prop";
            var expectedSortedColumn = new SortedColumn(propertyName, sortingDirection);
            var expectedHashCode = expectedSortedColumn.GetHashCode();
            var actualSortedColumn = new SortedColumn(propertyName, sortingDirection);

            // act
            var actualHashCode = actualSortedColumn.GetHashCode();

            // assert
            Assert.AreEqual(expectedHashCode, actualHashCode);
        }

        [TestMethod]
        public void GetHashCode_PropertyNamesDifferent_ReturnsDifferentHashCode()
        {
            // arrange
            const string sortingDirection = "asc";
            var expectedSortedColumn = new SortedColumn("Prop1", sortingDirection);
            var expectedHashCode = expectedSortedColumn.GetHashCode();
            var actualSortedColumn = new SortedColumn(null, sortingDirection);

            // act
            var actualHashCode = actualSortedColumn.GetHashCode();

            // assert
            Assert.AreNotEqual(expectedHashCode, actualHashCode);
        }

        [TestMethod]
        public void GetHashCode_SortingDirectionsDifferent_ReturnsDifferentHashCode()
        {
            // arrange
            const string propertyName = "Name";
            var expectedSortedColumn = new SortedColumn(propertyName, "asc");
            var expectedHashCode = expectedSortedColumn.GetHashCode();
            var actualSortedColumn = new SortedColumn(propertyName, "desc");

            // act
            var actualHashCode = actualSortedColumn.GetHashCode();

            // assert
            Assert.AreNotEqual(expectedHashCode, actualHashCode);
        }
    }
}
