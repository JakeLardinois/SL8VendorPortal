﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web.Mvc;
using jQuery.DataTables.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace jQuery.DataTables.Tests.Mvc
{
    [TestClass]
    public class JQueryDataTablesModelBinderTests
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void BindModel_NullBindingContextParameter_ThrowsArgumentNullException()
        {
            // arrange
            var dataTablesModelBinder = new JQueryDataTablesModelBinder();

            // act
            dataTablesModelBinder.BindModel(null, null);

            // assert

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void BindModel_NullsEcho_ThrowsInvalidOperationException()
        {
            // arrange
            var dataTablesModelBinder = new JQueryDataTablesModelBinder();
            var formCollection = new NameValueCollection();
            var valueProvider = new NameValueCollectionValueProvider(formCollection, null);
            var metadata = ModelMetadataProviders.Current.GetMetadataForType(null, typeof(JQueryDataTablesModel));
            var bindingContext = new ModelBindingContext
            {
                ModelName = "",
                ValueProvider = valueProvider,
                ModelMetadata = metadata
            };

            // act
            dataTablesModelBinder.BindModel(null, bindingContext);

            // assert

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void BindModel_iSortColCountIsInvalid_ThrowsInvalidOperationException()
        {
            // arrange
            var dataTablesModelBinder = new JQueryDataTablesModelBinder();
            var formCollection = new NameValueCollection
                                     {
                                         { "sEcho", "1" },
                                         { "iDisplayStart", "25" },
                                         { "iDisplayLength", "25" },
                                         { "sSearch", "test" },
                                         { "bRegex", "true" },
                                         { "iColumns", "2"},
                                         { "bSortable_0", "true"},
                                         { "bSortable_1", "false" },
                                         { "bSearchable_0", "true"},
                                         { "bSearchable_1", "false" },
                                         { "sSearch_0", "searching1"},
                                         { "sSearch_1", "searching2" },
                                         { "bRegex_0", "true"},
                                         { "bRegex_1", "false" },
                                         { "iSortingCols", "1" },
                                         { "sSortDir_0", "asc" },
                                         { "mDataProp_0", "Id"},
                                         { "mDataProp_1", "Name"}
                                     };
            var valueProvider = new NameValueCollectionValueProvider(formCollection, null);
            var metadata = ModelMetadataProviders.Current.GetMetadataForType(null, typeof(JQueryDataTablesModel));
            var bindingContext = new ModelBindingContext
            {
                ModelName = "",
                ValueProvider = valueProvider,
                ModelMetadata = metadata,
                FallbackToEmptyPrefix = true
            };

            // act
            dataTablesModelBinder.BindModel(null, bindingContext);

            // assert

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void BindModel_sSortDirCountIsInvalid_ThrowsInvalidOperationException()
        {
            // arrange
            var dataTablesModelBinder = new JQueryDataTablesModelBinder();
            var formCollection = new NameValueCollection
                                     {
                                         { "sEcho", "1" },
                                         { "iDisplayStart", "25" },
                                         { "iDisplayLength", "25" },
                                         { "sSearch", "test" },
                                         { "bRegex", "true" },
                                         { "iColumns", "2"},
                                         { "bSortable_0", "true"},
                                         { "bSortable_1", "false" },
                                         { "bSearchable_0", "true"},
                                         { "bSearchable_1", "false" },
                                         { "sSearch_0", "searching1"},
                                         { "sSearch_1", "searching2" },
                                         { "bRegex_0", "true"},
                                         { "bRegex_1", "false" },
                                         { "iSortingCols", "1" },
                                         { "iSortCol_0", "1" },
                                         { "mDataProp_0", "Id"},
                                         { "mDataProp_1", "Name"}
                                     };
            var valueProvider = new NameValueCollectionValueProvider(formCollection, null);
            var metadata = ModelMetadataProviders.Current.GetMetadataForType(null, typeof(JQueryDataTablesModel));
            var bindingContext = new ModelBindingContext
            {
                ModelName = "",
                ValueProvider = valueProvider,
                ModelMetadata = metadata,
                FallbackToEmptyPrefix = true
            };

            // act
            dataTablesModelBinder.BindModel(null, bindingContext);

            // assert

        }

        [TestMethod]
        public void BindModel_ValidValues_ReturnsJQueryDataTablesModel()
        {
            // arrange
            var dataTablesModelBinder = new JQueryDataTablesModelBinder();
            var formCollection = new NameValueCollection
                                     {
                                         { "sEcho", "1" },
                                         { "iDisplayStart", "25" },
                                         { "iDisplayLength", "25" },
                                         { "sSearch", "test" },
                                         { "bRegex", "true" },
                                         { "iColumns", "2"},
                                         { "bSortable_0", "true"},
                                         { "bSortable_1", "false" },
                                         { "bSearchable_0", "true"},
                                         { "bSearchable_1", "false" },
                                         { "sSearch_0", "searching1"},
                                         { "sSearch_1", "searching2" },
                                         { "bRegex_0", "true"},
                                         { "bRegex_1", "false" },
                                         { "iSortingCols", "1" },
                                         { "iSortCol_0", "1" },
                                         { "sSortDir_0", "asc" },
                                         { "mDataProp_0", "Id"},
                                         { "mDataProp_1", "Name"}
                                     };
            var valueProvider = new NameValueCollectionValueProvider(formCollection, null);
            var metadata = ModelMetadataProviders.Current.GetMetadataForType(null, typeof(JQueryDataTablesModel));
            var bindingContext = new ModelBindingContext
            {
                ModelName = "",
                ValueProvider = valueProvider,
                ModelMetadata = metadata,
                FallbackToEmptyPrefix = true
            };
            var expectedSortables = new[] { true, false };
            var expectedSearchables = new[] { true, false };
            var expectedSearches = new[] { "searching1", "searching2" };
            var expectedRegexes = new[] { true, false };
            var expectedColumnSortIndexes = new[] { 1 };
            var expectedColumnSortDirections = new[] { "asc" };
            var expectedDataProperties = new[] {"Id", "Name"};
            var expectedSortedColumns = new List<SortedColumn>();
            expectedSortedColumns.Add(new SortedColumn("Name", "asc"));

            // act
            var model = (JQueryDataTablesModel)dataTablesModelBinder.BindModel(null, bindingContext);

            // assert
            Assert.AreEqual(1, model.sEcho, "Expected sEcho to be 1");
            Assert.AreEqual(25, model.iDisplayStart, "Expected iDisplayStart to be 25");
            Assert.AreEqual(25, model.iDisplayLength, "Expected iDisplayLength to be 25");
            Assert.AreEqual("test", model.sSearch, "Expected sSearch to be test");
            Assert.IsTrue(model.bRegex, "Expected bRegex to be true");
            Assert.AreEqual(2, model.iColumns, "Expected iColumns to be 2");
            CollectionAssert.AreEqual(expectedSortables, model.bSortable_, "Expected bSortable to be true,false");
            CollectionAssert.AreEqual(expectedSearchables, model.bSearchable_, "Expected bSearchable to be true,false");
            CollectionAssert.AreEqual(expectedSearches, model.sSearch_, "Expected sSearch to be searching1,searching2");
            CollectionAssert.AreEqual(expectedRegexes, model.bRegex_, "Expected bRegex to be true,false");
            Assert.AreEqual(1, model.iSortingCols, "Expected iSortingCols to be 1");
            CollectionAssert.AreEqual(expectedColumnSortIndexes, model.iSortCol_, "Expected iSortCol to be 1");
            CollectionAssert.AreEqual(expectedColumnSortDirections, model.sSortDir_, "Expected sSortDir to be asc");
            CollectionAssert.AreEqual(expectedDataProperties, model.mDataProp_, "Expected mDataProp to be Id,Name");
            CollectionAssert.AreEqual(expectedSortedColumns, model.GetSortedColumns(), "Expected a PropertyName of Name and SortinDirection of Ascending");
        }
    }
}
