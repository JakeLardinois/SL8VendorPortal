﻿using System.Web.Mvc;
using jQuery.DataTables.Mvc;
using jQuery.DataTables.Web.Code;
using jQuery.DataTables.Web.Models;

namespace jQuery.DataTables.Web.Controllers
{
    public class CustomerController : Controller
    {
        [HttpGet]
        public ActionResult Search()
        {
            return View("Search");
        }

        [HttpPost]
        public JsonResult Search(JQueryDataTablesModel jQueryDataTablesModel)
        {
            int totalRecordCount;
            int searchRecordCount;
            var customers = InMemoryCustomersRepository.GetCustomers(startIndex: jQueryDataTablesModel.iDisplayStart,
                pageSize: jQueryDataTablesModel.iDisplayLength, sortedColumns: jQueryDataTablesModel.GetSortedColumns(), 
                totalRecordCount: out totalRecordCount, searchRecordCount: out searchRecordCount, searchString: jQueryDataTablesModel.sSearch);

            return this.DataTablesJson(items: customers, 
                totalRecords: totalRecordCount,
                totalDisplayRecords: searchRecordCount,
                sEcho: jQueryDataTablesModel.sEcho);
        }

    [HttpGet]
    public ViewResult CustomSearch()
    {
        return View("CustomSearch");
    }

    [HttpPost]
    public JsonResult CustomSearch(JQueryDataTablesModel jQueryDataTablesModel, CustomerSearchModel searchModel)
    {
        int totalRecordCount;
        int searchRecordCount;
        var customers = InMemoryCustomersRepository.GetCustomers(startIndex: jQueryDataTablesModel.iDisplayStart,
            pageSize: jQueryDataTablesModel.iDisplayLength, sortedColumns: jQueryDataTablesModel.GetSortedColumns(),
            totalRecordCount: out totalRecordCount, searchRecordCount: out searchRecordCount, searchModel: searchModel);

        return this.DataTablesJson(items: customers,
            totalRecords: totalRecordCount,
            totalDisplayRecords: searchRecordCount,
            sEcho: jQueryDataTablesModel.sEcho);
    }

    }
}
